﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Setting_Scene : MonoBehaviour {

    public void Modify_Setting_Scene_Button() //Setting 수정 화면으로 이동
    {

        SceneManager.LoadScene("Setting_Scene"); // 문제 선택페이지로 다시 이동
    }

    public void Complete_Setting_Button() //Setting 수정 완료 버튼 
    {

        SceneManager.LoadScene("Select_Question"); // 문제 선택페이지로 다시 이동
    }

    public void Back_to_Before_Scene_Button() //이전 화면으로 돌아가는 버튼
    {

        SceneManager.LoadScene("Select_Question"); // 문제 선택페이지로 다시 이동
    }
}
