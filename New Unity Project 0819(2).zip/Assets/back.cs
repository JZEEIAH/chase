﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class back : MonoBehaviour
{


    private void Awake()
    {

    }
    public void StartButton()
    {
        Invoke("startgame", .50f);

    }

    void startgame()
    {
        Application.LoadLevel("page2");
    }

}
