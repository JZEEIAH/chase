﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Gamemanager : MonoBehaviour {
    [Header("LoginPanel")]
    public InputField IDInputField;
    public InputField PWInputField;

    [Header("JoinPanel")]
    public InputField New_IDInputField;
    public InputField New_PWInputField;
    public InputField Confirm_PWInputField;
    public InputField New_EmailInputField;
    public InputField BirthInputField;
    public GameObject JoinPanelObj;
    public GameObject LoginPanelObj;
    public Button Back_JoinButton;

    [Header("YesorNoPanel")]

    public InputField MyAnswerInputField;
    public InputField HintInputField;
    public GameObject YesorNoPanelObj;

    [Header("QuestionPanel")]

    //public Text QuestionPanelText;
    public Text QusetionPanelText;
    public Text Textexample;
    public InputField keyword_InputField;
    public InputField Reason_InputField;
    public GameObject QuestionPanelObj;

    [Header("ImageTextPanel")]

    public Image Question_Image;
    public Text Question_Text;
    public GameObject ImageTextPanelObj;

    
    

    public string LoginUrl;
    public string JoinUrl;

    // Use this for initialization
    void Start () {
     
        LoginUrl = "ckdal34.cafe24.com/chase/Login.php";
        JoinUrl = "ckdal34.cafe24.com/test/login/t_join.php";
    }

    public void LoginBtn()
    {
        StartCoroutine(LoginCo());
    }

   
   

IEnumerator LoginCo()
    {
        //Debug.Log(IDInputField.text);
        //Debug.Log(PWInputField.text);

        WWWForm form = new WWWForm();
        form.AddField("id", IDInputField.text);
        form.AddField("pwd", PWInputField.text);

        WWW webRequest = new WWW(LoginUrl, form);

        yield return webRequest;
        Debug.Log(webRequest.text);

        

    }
    
    public void OpenJoinBtn()
    {
        JoinPanelObj.SetActive(true);
    }


    public void JoinBtn()
    {
        StartCoroutine(CreateCo());
    }

    IEnumerator CreateCo()
    {
        
        WWWForm form = new WWWForm();
        form.AddField("new_id", New_IDInputField.text);
        form.AddField("new_pwd", New_PWInputField.text);
        //form.AddField("pwd_confirm", Confirm_PWInputField.text);
       // form.AddField("new_email", New_EmailInputField.text);
       // form.AddField("new_birth", BirthInputField.text);
      

        WWW webRequest = new WWW(JoinUrl, form);
        yield return webRequest;

        Debug.Log(webRequest.text);
        //StopCoroutine("ChangeMovement");
        
    }

    public void complete_Join_Button()
    {
        SceneManager.LoadScene("page2");
    }


    public void BackJoinBtn()
    {
        LoginPanelObj.SetActive(true);
        JoinPanelObj.SetActive(false);
    }

    public void EnterButton()
    {
        YesorNoPanelObj.SetActive(true);

        //StartCoroutine(LoginCo());

    }

    public void Image_Text_Button()
    {
        ImageTextPanelObj.SetActive(true);
    }
    
}
