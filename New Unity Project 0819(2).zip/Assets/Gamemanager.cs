﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour {
    [Header("LoginPanel")]
    public InputField IDInputField;
    public InputField PWInputField;

    [Header("JoinPanel")]
    public InputField New_IDInputField;
    public InputField New_PWInputField;
    public InputField Confirm_PWInputField;
    public InputField New_EmailInputField;
    public InputField BirthInputField;
    public GameObject JoinPanelObj;
    public GameObject LoginPanelObj;

    [Header("YesorNoPanel")]

    public InputField MyAnswerInputField;
    public InputField HintInputField;
    public GameObject YesorNoPanelObj;

    [Header("QuestionPanel")]

    public InputField keyword_InputField;
    public InputField Reason_InputField;


    public string LoginUrl;
    public string JoinUrl;

    // Use this for initialization
    void Start () {

        LoginUrl = "ckdal34.cafe24.com/chase/Login.php";
        JoinUrl = "ckdal34.cafe24.com/chase/Join.php";
    }
	
    public void LoginBtn()
    {
        StartCoroutine(LoginCo());
    }

IEnumerator LoginCo()
    {
        //Debug.Log(IDInputField.text);
        //Debug.Log(PWInputField.text);

        WWWForm form = new WWWForm();
        form.AddField("id", IDInputField.text);
        form.AddField("pwd", PWInputField.text);

        WWW webRequest = new WWW(LoginUrl, form);
        yield return webRequest;

        Debug.Log(webRequest.text);


    }
    
    public void OpenJoinBtn()
    {
        JoinPanelObj.SetActive(true);

        //StartCoroutine(LoginCo());

    }

    public void JoinBtn()
    {
        StartCoroutine(CreateCo());
    }

    IEnumerator CreateCo()
    {

       Debug.Log(New_IDInputField.text);
       // Debug.Log(PWInputField.text);

        WWWForm form1 = new WWWForm();
        form1.AddField("new_id", New_IDInputField.text);
        form1.AddField("new_pwd", New_PWInputField.text);
        form1.AddField("pwd_confirm", Confirm_PWInputField.text);
        form1.AddField("new_email", New_EmailInputField.text);


        WWW webRequest = new WWW(JoinUrl, form1);
        yield return webRequest;

        Debug.Log(webRequest.text);
        //StopCoroutine("ChangeMovement");

    }


    public void BackJoinBtn()
    {
        LoginPanelObj.SetActive(true);

        //StartCoroutine(LoginCo());

    }

}
