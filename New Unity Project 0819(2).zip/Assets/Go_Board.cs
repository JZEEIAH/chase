﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Go_Board : MonoBehaviour {

    public void Go_Board_Button() //게시판 이동 버튼
    {
        SceneManager.LoadScene("Board");
    }

    public void GoBack_Question_Button() //게시판 누르기 전 문제(내가 말한 답, Hint) 창으로 이동하는 버튼 
    {
        SceneManager.LoadScene("yesorno");
    }


    public void Many_keyword_Button() // 다언급키워드 확인 버튼 
    {
        SceneManager.LoadScene("Many_Keyword_Scene");
    }

}
