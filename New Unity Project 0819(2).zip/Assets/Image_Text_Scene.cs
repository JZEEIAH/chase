﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Image_Text_Scene : MonoBehaviour {

    [Header("ImageTextPanel")]

    public Image Question_Image;
    public Text Question_Text;
    public GameObject ImageTextPanelObj;

    public void Image_Text_X_Button()
    {
        SceneManager.LoadScene("Page3");
    }

}

