﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Tutorial : MonoBehaviour {


    [Header("Tutorial_Panel")]

    public GameObject Tutorial_PanelObj;



    public void See_Tutorial_Button() //튜토리얼 보는 버튼 
    {
        SceneManager.LoadScene("Tutorial");
    }

    public void Back_to_select_stage_Scene_Button()
    {

        SceneManager.LoadScene("Select_Stage");
    }


}
