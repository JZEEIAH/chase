﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Many_keyword : MonoBehaviour {

    public void Close_Many_keyword_Button() //다언급 키워드 창 닫기 버튼 
    {
        SceneManager.LoadScene("Board");
    }
}
