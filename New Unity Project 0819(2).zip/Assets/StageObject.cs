﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StageObject : MonoBehaviour

{

    [Header("Select_Stage_ListView_Panel")]

    public GameObject Select_Stage_ListView_PanelObj;


    public Button Item;

    public void Select_Stage_and_Solve_Question_Button() //스테이지를 선택하고 문제푸는 화면으로 이동하는 버튼 
    {

        SceneManager.LoadScene("Try_it");
    }

}
