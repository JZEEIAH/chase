﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;



public class Criminal : MonoBehaviour {

    public void Go_Hint_Scene_Button() // 보석함페이지로 이동하는 버튼
    {

        SceneManager.LoadScene("HintBox"); // 보석함 페이지로 이동
    }

}
