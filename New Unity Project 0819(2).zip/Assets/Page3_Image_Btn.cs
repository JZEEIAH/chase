﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Page3_Image_Btn : MonoBehaviour {


    public void Detail_Image_Button()
    {
        SceneManager.LoadScene("ImageScene");
    }

    
}
