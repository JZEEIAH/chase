﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Hint : MonoBehaviour {



    public void Show_Hint() //힌트를 확인할 수 있는 버튼
    {

        SceneManager.LoadScene("Hint_Scene");
    }


    public void Close_Hint() //힌트 확인 후 닫기 버튼
    {

        SceneManager.LoadScene("Select_Question");
    }


}
