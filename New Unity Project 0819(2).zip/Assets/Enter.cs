﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Enter : MonoBehaviour  //문제화면에서 입력 완료 버튼 누르는! 
{

    [Header("Question_Panel")]

    public GameObject Question_PanelObj;


    public void confirm_answer_button () //답을 입력한 후 입력완료 버튼을 눌러 yesorno 씬(해당 씬은 오답의 여부를 알 수 있으면 hint 또한 확인 가능)으로 이동하는 버튼
    {

        SceneManager.LoadScene("yesorno");
    }

}

	