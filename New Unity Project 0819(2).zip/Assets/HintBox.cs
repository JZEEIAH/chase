﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HintBox : MonoBehaviour {

    public void Extra_Hint_Button() 
    {

        SceneManager.LoadScene("Extra_Hint"); // 보석함 중 하나의 보석함을 선택하여 힌트 확인 페이지로 이동
    }

}
